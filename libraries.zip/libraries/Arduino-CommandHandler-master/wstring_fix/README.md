Ubunto arduino package is old, wstring is not suitable for the library we developed.

Copy/Paste/Replace the wstring files from here to: /usr/share/arduino/hardware/arduino/cores/arduino, or the equivalent location on your system.
